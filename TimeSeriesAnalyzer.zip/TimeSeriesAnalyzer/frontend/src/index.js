import React from 'react';
import ReactDOM from 'react-dom/client';
import './TimeSeriesAnalyzer.css';
import TimeSeriesAnalyzer from './TimeSeriesAnalyzer';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <TimeSeriesAnalyzer/>
  </React.StrictMode>
);