import React, {useState, useEffect, useMemo} from 'react';
import {LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer} from 'recharts';
import './TimeSeriesAnalyzer.css';

function TimeSeriesAnalyzer() {
    const [instrument, setInstrument] = useState('Inst1');
    const [display, setDisplay] = useState('price');
    const [maDays, setMaDays] = useState(7);
    const [quantile, setQuantile] = useState(0);

    const [data, setData] = useState({});
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        setLoading(true);
        fetch('http://localhost:8000/')
            .then(response => response.json())
            .then(result => {
                const groupedData = result.reduce((acc, {instrument, date, price}) => {
                    (acc[instrument] = acc[instrument] || []).push({date, price});
                    return acc;
                }, {});

                setData(groupedData);
                setLoading(false);
            })
            .catch(e => {
                console.error("Error:", e);
            })
            .finally(() => {
                setLoading(false);
            });
    }, []);


    const chartData = useMemo(() => {
        const instrumentData = data[instrument];
        if (!instrumentData) return [];

        const sortedData = [...instrumentData].sort(
            (a, b) => new Date(a.date) - new Date(b.date)
        );

        let filteredData = sortedData;

        if (quantile > 0) {
            const prices = sortedData.map(item => item.price).sort((a, b) => a - b);
            const lowerBound = prices[Math.floor(prices.length * quantile)];
            const upperBound = prices[Math.floor(prices.length * (1 - quantile))];

            filteredData = sortedData.filter(point => point.price >= lowerBound && point.price <= upperBound);
        }

        if (display === 'moving_average') {
            return filteredData.map((point, i, array) => {
                const window = array.slice(Math.max(0, i - (maDays - 1)), i + 1);
                const avg = window.reduce((sum, item) => sum + item.price, 0) / window.length;
                return {...point, moving_average: avg};
            });
        }

        return filteredData;
    }, [data, instrument, display, maDays, quantile]);

    return (
        <div>
            <h1>Time Series Analyzer</h1>

            <div className="toolbar">
                <div className="toolbarItem">
                    <label>Instrument</label>
                    <select
                        value={instrument}
                        onChange={e => setInstrument(e.target.value)}
                        disabled={loading}
                    >
                        {Object.keys(data).map(inst => (<option key={inst}>{inst}</option>))}
                    </select>
                </div>

                <div className="toolbarItem">
                    <label>Display</label>
                    <select
                        value={display}
                        onChange={e => setDisplay(e.target.value)}
                        disabled={loading}
                    >
                        <option value="price">Price</option>
                        <option value="moving_average">Moving Average</option>
                    </select>
                </div>

                {display === 'moving_average' && (
                    <div className="toolbarItem">
                        <label>Days</label>
                        <input
                            type="number"
                            min="2"
                            max="461"
                            value={maDays}
                            onChange={e => setMaDays(parseInt(e.target.value) || 7)}
                            disabled={loading}
                        />
                    </div>
                )}

                <div className="toolbarItem">
                    <label>Price quantile (0.00-0.10)</label>
                    <input
                        type="number"
                        min="0.00"
                        max="0.1"
                        step="0.01"
                        value={quantile}
                        onChange={e => setQuantile(parseFloat(e.target.value) || 0)}
                        disabled={loading}
                    />
                </div>
            </div>

            <div className="chart-container">
                {loading ? (
                    <p>Loading...</p>
                ) : (
                    <ResponsiveContainer>
                        <LineChart data={chartData}>
                            <XAxis
                                dataKey="date"
                                tick={{fontSize: 10}}
                                tickFormatter={value => new Date(value).toLocaleDateString('en-GB')}
                            />
                            <YAxis domain={['auto', 'auto']} tick={{fontSize: 10}}/>
                            <Tooltip
                                formatter={value => `$${value.toFixed(2)}`}
                                contentStyle={{backgroundColor: '#333333', color: '#ffffff'}}
                            />
                            <Line
                                dataKey={display}
                                name={`${instrument} ${display === 'moving_average' ? 'Moving Average' : 'Price'}`}
                                dot={false}
                                strokeWidth={2}
                            />
                        </LineChart>
                    </ResponsiveContainer>
                )}
            </div>
        </div>
    );
}

export default TimeSeriesAnalyzer;