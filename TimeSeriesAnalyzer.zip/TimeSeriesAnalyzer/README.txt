### Packages ###
Outside of the default package provided by react the frontend also imports the package 'recharts' for the design of the chart.


### Steps to run the code ###

# BACKEND #
Navigate to \TimeSeriesAnalyzer\backend\

Run the commands:
1. python manage.py import_instrument_data
2. python manage.py runserver

Check that the API is hosted on the local development server (keep this running).

# FRONTEND #
Open up a new command line and navigate to \TimeSeriesAnalyzer\frontend\

Run the commands:
1. npm install
2. npm start

Open up the application on the secondary localhost path
