from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Instruments',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('instrument', models.CharField(max_length=10)),
                ('date', models.DateField()),
                ('price', models.FloatField()),
            ],
            options={
                'db_table': 'time_series_instruments',
            },
        ),
    ]
