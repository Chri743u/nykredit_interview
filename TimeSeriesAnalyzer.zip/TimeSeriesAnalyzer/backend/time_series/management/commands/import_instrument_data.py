import json
import os
from django.core.management.base import BaseCommand
from django.conf import settings
from datetime import datetime
from time_series.models import Instruments


class Command(BaseCommand):
    help = 'Imports price data'

    def handle(self, *args, **options):
        project_root = os.path.dirname(settings.BASE_DIR)
        file_path = os.path.join(project_root, 'data', 'input_data.json')

        with open(file_path, 'r') as file:
            data = json.load(file)

        count = 0
        date_fixed = 0

        for instrument, entries in data.items():
            for entry in entries:
                date_str = entry['date']
                try:
                    date = datetime.strptime(date_str, '%Y-%m-%d').date()
                except ValueError:
                    year, month, day = date_str.split('-')
                    if int(month) > 12:
                        date = datetime.strptime(f"{year}-{day}-{month}", '%Y-%m-%d').date()
                        date_fixed += 1
                    else:
                        continue

                price = float(entry['price']) if entry['price'] is not None else 0
                Instruments.objects.create(instrument=instrument, date=date, price=price)
                count += 1

        self.stdout.write(f"Imported {count} entries. Fixed {date_fixed} dates with invalid date.")