from rest_framework.views import APIView
from rest_framework.response import Response
from .models import Instruments
from .serializers import InstrumentsSerializer


class InstrumentPriceView(APIView):
    def get(self, request):
        data = Instruments.objects.all()
        serializer = InstrumentsSerializer(data, many=True)
        return Response(serializer.data)