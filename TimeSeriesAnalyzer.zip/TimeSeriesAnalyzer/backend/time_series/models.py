from django.db import models


class Instruments(models.Model):
    instrument = models.CharField(max_length=10)
    date = models.DateField()
    price = models.FloatField()

    class Meta:
        db_table = 'time_series_instruments'