from django.urls import path
from time_series.views import InstrumentPriceView

urlpatterns = [
    path('', InstrumentPriceView.as_view()),
]